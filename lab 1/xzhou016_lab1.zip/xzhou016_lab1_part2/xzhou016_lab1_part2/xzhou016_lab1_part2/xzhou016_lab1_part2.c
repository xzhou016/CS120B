/*
 * xzhou016_lab1_part2.c
 *
 * Created: 7/25/2016 3:15:31 PM
 *  Author: student
 */ 


#include <avr/io.h>


int main(void)
{
   DDRA = 0x00; PORTA = 0xFF;
   DDRC = 0x0F; PORTC = 0x00;
   
   unsigned char cntavail = 0x00;
   
   
   while(1)
   {
		cntavail = (PINA & 0x01) + (PINA >> 1 & 0x01) + (PINA >> 2 & 0x01) + (PINA >> 3 & 0x01);
		cntavail = 4 - cntavail;
		PORTC = cntavail;
	}

   return 0;
}