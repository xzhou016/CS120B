/*
 * xzhou016_lab1_part4.c
 *
 * Created: 7/25/2016 4:47:56 PM
 *  Author: student
 */ 


#include <avr/io.h>

int main(void)
{
	//input
	DDRA = 0x00; PORTA = 0xFF;
	DDRB = 0x00; PORTB = 0xFF;
	DDRC = 0x00; PORTC = 0xFF;
	
	//output
	DDRD = 0xFF; PORTD = 0xFF;
	
	
    while(1)
    {
       if ((PINA + PINB + PINC) >= 0x8C )
       {
		   PORTD = PORTD | 0x01;
       }
	   else 
	   {
		   PORTD = PORTD & 0xFE;
	   }
	   
	   if ( (PINA - PINC > 0x50 ) || (PINC - PINA > 0x50))
	   {
		   PORTD = PORTD | 0x02;
	   }
	   else
	   {
		   PORTD = PORTD & 0xFD;
	   }
	   
	   unsigned char tempCalc = PINA + PINB;
	   tempCalc = tempCalc >> 1;
	   tempCalc += PINC;
	   tempCalc = tempCalc >> 1;
	   tempCalc = tempCalc >> 3;
	   tempCalc = tempCalc << 2;
	   PORTD = (PORTD & 0x03 )| tempCalc ;
	
    }
	
	return 0;
}

