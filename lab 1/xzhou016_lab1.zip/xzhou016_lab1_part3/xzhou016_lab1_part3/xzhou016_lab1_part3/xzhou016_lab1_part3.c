/*
 * xzhou016_lab1_part3.c
 *
 * Created: 7/25/2016 4:10:04 PM
 *  Author: student
 */ 


#include <avr/io.h>

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF;
	DDRC = 0xFF; PORTC = 0x00;
	
	unsigned char cntavail = 0x00;
	
	
	while(1)
	{	
		cntavail = (PINA & 0x01) + (PINA >> 1 & 0x01) + (PINA >> 2 & 0x01) + (PINA >> 3 & 0x01);
		cntavail = 4 - cntavail;
		PORTC = cntavail;

		if (cntavail == 0)
		{
			PORTC = PORTC | 0x80;
		}
		else 
		{
			PORTC = PORTC & 0x7F;
		}

		
	}

	return 0;
}