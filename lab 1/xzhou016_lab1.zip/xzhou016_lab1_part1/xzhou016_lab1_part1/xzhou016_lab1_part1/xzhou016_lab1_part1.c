/*
 * xzhou016_lab1_part1.c
 *
 * Created: 7/25/2016 1:59:37 PM
 *  Author: student
 */ 


#include <avr/io.h>

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF;
	DDRB = 0x01; PORTB = 0x00;
	
	unsigned char tempOut = 0x00;
	
	
    while(1)
    {
        if ((!(PINA & 0x02 )) & (PINA & 0x01))
        {
			tempOut = (tempOut & 0x00) | 0x01;
        }
		else
		{
			tempOut = (tempOut & 0x00) | 0x00;
		}
	PORTB = tempOut;
    }
	
return 0;
}